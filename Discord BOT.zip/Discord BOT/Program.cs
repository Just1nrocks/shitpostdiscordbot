﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Discord;
using Discord.Commands;
using System.IO;

namespace Discord_BOT
{

    class Program
    {

        #region


        

        class Datum
        {
            public string story { get; set; }
            public string created_time { get; set; }
            public string id { get; set; }
            public string message { get; set; }
        }

        class Paging
        {
            public string previous { get; set; }
            public string next { get; set; }
        }

        class RootObject
        {
            public List<Datum> data { get; set; }
            public Paging paging { get; set; }
        }
       
        public class fbk : System.Net.WebClient
        {
            static Random rnd = new Random();

            private string key = "EAACEdEose0cBAKpEOojVsfzCQtV2EM2RyU5A1Kcuec4qvr2jvuHKMaS46LIlC5cZCZCTSPgtvv0c19njqHfNjP2sQMCODqUJI8GVVRl9mGVwEneKq0d0P33ZAu9O9fq6NkgJjkP6eT4oFmc6LcKWAcf1hdcUAUIt6mkZBDZBrLAZDZD";
            public shitpost shitpost()
            {
                var shitpostfeed = "https://graph.facebook.com/v2.6/" + getfeed().id + "?fields=full_picture%2Cpicture&access_token="+ key;
                this.Headers.Add("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.0.3705;)");
                Console.WriteLine(shitpostfeed);
                Stream data = this.OpenRead(shitpostfeed);
                StreamReader reader = new StreamReader(data);
                string s = reader.ReadToEnd();
             
                data.Close();
                reader.Close();
                var shitpost = Newtonsoft.Json.JsonConvert.DeserializeObject<shitpost>(s);
                return shitpost;
                
            }

            private Datum getfeed()
            {
                var shitpostfeed = "https://graph.facebook.com/v2.6/shitpostbot/feed?access_token="+key;
                this.Headers.Add("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.0.3705;)");

                Stream data = this.OpenRead(shitpostfeed);
                StreamReader reader = new StreamReader(data);
                string s = reader.ReadToEnd();
                Console.WriteLine(s);
                data.Close();
                reader.Close();
               
                var feed = Newtonsoft.Json.JsonConvert.DeserializeObject<RootObject>(s);
                
                int r = rnd.Next(feed.data.Count);
                return feed.data[r];


            }

        }
        public class shitpost
        {

            public string full_picture { get; set; }
            string picture { get; set; }
            public string id { get; set; }


        }

        #endregion
        static void Main(string[] args)
        {
            fbk xx = new fbk();

            var client = new DiscordClient();


            //Display all log messages in the console
            client.UsingCommands(x =>
            {
                x.PrefixChar = '~';
            });

            //Echo back any message received, provided it didn't come from the bot itself

            //Convert our sync method to an async one and block the Main function until the bot disconnects
            client.ExecuteAndWait(async () =>
            {
                //Connect to the Discord server using our email and password
                await client.Connect("MTk5OTc2NjgyNTI4OTY0NjEw.Cl2viA.x0LuPfGmrja-mEu6EjUcZVLw8K4");
                client.GetService<CommandService>().CreateCommand("spb")

     //create command greet


     .Description("Gives You A DAILY DOSE OF SHITPOST") //add description, it will be shown when ~help is used

     .Do(async e =>
     {

         var pic = xx.shitpost().full_picture;
         Console.WriteLine(pic);
         Console.WriteLine("Command FIRED");
         await e.Channel.SendMessage(pic);
         //sends a message to channel with the given text
         
     });



            });





        }
    }
}
